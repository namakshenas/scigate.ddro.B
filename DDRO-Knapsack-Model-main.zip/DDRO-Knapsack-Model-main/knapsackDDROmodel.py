import numpy as np
from gurobipy import Model, GRB
from supportVectorClustering import *


def ddro_knapsack(weight, utility, capacity, p_regul):
    n_items = len(utility)

    # Extracting SVC outputs
    Q = whitening_matrix(weight)
    SV, BSV, v_alpha_array_trunc = support_vectors(weight, p_regul)
    p_alpha_SV = v_alpha_array_trunc[SV]
    p_a_SV = weight[:, SV]
    p_a_BSV = weight[:, BSV]
    p_num_SV = SV.size
    p_num_BSV = BSV.size
    # Choose minimum BSV since it produces smaller theta and tight uncertainty set.
    p_theta_vec = np.zeros(p_num_BSV)
    for ip in range(p_num_BSV):
        p_theta_vec[ip] = np.sum(
            [p_alpha_SV[i] * np.linalg.norm(np.dot(Q, p_a_BSV[:, ip] - p_a_SV[:, i]), 1) for i in range(p_num_SV)])
    p_theta = np.min(p_theta_vec)

    # Developing Knapsack DDRO Counterpart
    model = Model("ddro_knapsack")
    model.setParam('OutputFlag', 0)
    v_select = model.addMVar(n_items, vtype=GRB.BINARY)
    v_dual_eta = model.addVar()
    v_dual_la = model.addMVar((n_items, p_num_SV))
    v_dual_mu = model.addMVar((n_items, p_num_SV))

    # Defining objective
    model.setObjective(sum(v_select[j] * utility[j] for j in range(n_items)), GRB.MAXIMIZE)

    # DDRO-based constraints
    model.addConstr(sum(np.dot(Q, p_a_SV[:, i]).T @ v_dual_la[:, i] for i in range(p_num_SV)) -
                    sum(np.dot(Q, p_a_SV[:, i]).T @ v_dual_mu[:, i] for i in
                        range(p_num_SV)) + v_dual_eta * p_theta <= capacity)
    for j in range(n_items):
        for i in range(p_num_SV):
            model.addConstr(v_dual_la[j, i] + v_dual_mu[j, i] == v_dual_eta * p_alpha_SV[i])
    model.addConstr(sum(Q @ v_dual_la[:, i] for i in range(p_num_SV)) -
                    sum(Q @ v_dual_mu[:, i] for i in range(p_num_SV)) - v_select == 0)

    model.optimize()
    status = model.status
    if status == GRB.OPTIMAL:
        value_v_select = np.array([v_select[s].X for s in range(n_items)], dtype=int)
        obj = np.round(model.objVal, 2)
    return obj, value_v_select
