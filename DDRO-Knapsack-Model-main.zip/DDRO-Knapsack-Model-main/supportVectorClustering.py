import numpy as np
from ZCAmatrix import *
from gurobipy import Model, GRB


def support_vectors(a, p_regul):
    # Calling the whitening matrix
    Q = whitening_matrix(a)

    # Making the kernel matrix PSD
    l_psd = np.zeros(a.shape[0])
    for i in range(a.shape[0]):
        l_ub = np.max(np.dot(Q[i, :].T, a))
        l_lb = np.min(np.dot(Q[i, :].T, a))
        l_psd[i] = l_ub - l_lb + .0001

    # Computing the kernel matrix
    ker_mat = np.zeros((a.shape[1], a.shape[1]))
    for u in range(a.shape[1]):
        for v in range(a.shape[1]):
            ker_mat[u, v] = np.sum(l_psd) - np.linalg.norm(np.dot(Q, a[:, u] - a[:, v]), 1)

    # Developing the SVC model
    svc = Model("support-vector-clustering")
    svc.setParam('OutputFlag', 0)
    p_ker_mat = ker_mat
    v_alpha = svc.addVars(a.shape[1], lb=0, ub=1 / (a.shape[1] * p_regul))
    svc.addConstr(sum(v_alpha[i] for i in range(a.shape[1])) == 1)
    svc.setObjective(sum(v_alpha[i] * v_alpha[j] * p_ker_mat[i, j] for i in range(a.shape[1])
                         for j in range(a.shape[1])) - sum(v_alpha[i] * p_ker_mat[i, i] for i in range(a.shape[1])))
    svc.optimize()
    status = svc.status
    if status == GRB.OPTIMAL:
        v_alpha_dict = [v_alpha[s].X for s in range(a.shape[1])]
        v_alpha_array_trunc = np.round(np.array(v_alpha_dict), 2)

    # Retrieving the support vectors and boundary support vectors
    SV = np.where(v_alpha_array_trunc > 0)
    BSV = np.where((v_alpha_array_trunc > 0) & (v_alpha_array_trunc < 1 / (a.shape[1] * p_regul)))

    SV = np.array(SV).ravel()
    BSV = np.array(BSV).ravel()

    return SV, BSV, v_alpha_array_trunc
