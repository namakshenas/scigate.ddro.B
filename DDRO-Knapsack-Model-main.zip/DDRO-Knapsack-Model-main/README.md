# DDRO-Knapsack-Model
This project is intended to reproduce a data-driven robust optimization method and implement it on a knapsack problem.
