"""
This project is intended to reproduce a data-driven robust optimization method described in [1] and implement it on
a knapsack problem. To run the project, please install the gurobi package with a valid licence. For more information
email me: m.n.shenas@gmail.com.
--
[1]. Shang, Chao, Xiaolin Huang, and Fengqi You. "Data-driven robust optimization based on kernel learning."
Computers & Chemical Engineering 106 (2017): 464-479.
"""

__author__ = "Mohammad Namakshenas"
__copyright__ = "Copyright 2022, scigate.org"

import pandas as pd
from knapsackDDROmodel import *
import numpy as np

if __name__ == '__main__':
    utility = [26, 65, 35, 48, 26, 53, 32, 48, 58, 62]
    capacity = 120
    p_regul = .1
    df = pd.read_csv("knapsack-ddro.csv")
    weight = df.to_numpy()

    obj, selections = ddro_knapsack(weight, utility, capacity, p_regul)

    print("----------------------------------")
    print("----------------------------------")
    print("Data-driven Knapsack Model Solution:")
    print("objective: ", obj)
    print("x: ", selections)
    print("----------------------------------")
    print("----------------------------------")
